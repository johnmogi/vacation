import * as React from "react";
import { Component, ChangeEvent } from "react";
import { UserLog } from "../../models/user-model";
interface LoginState {
  user: UserLog[];
}

export class SignIn extends Component<any, LoginState> {
  public constructor(props: any) {
    super(props);
    this.state = {
      user: []
    };
  }

  public testClick() {
    alert("click");
  }
  render() {
    return (
      <div className="signin">
        <h2> Wellcome back Mitey...</h2>
        <form>
          <input type="text" placeholder="User Name" />
          <br /> <br />
          <input type="text" placeholder="Password" />
          <br /> <br />
          <button type="button" onClick={this.testClick}>
            Log me in, Scottie!
          </button>
        </form>
      </div>
    );
  }
}
