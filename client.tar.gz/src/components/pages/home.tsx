import * as React from "react";
import { Component } from "react";

export class Home extends Component {
  render() {
    return (
      <div className="home">
        <h1>home</h1>
      </div>
    );
  }
}
