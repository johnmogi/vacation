import * as React from 'react';
import { Component } from 'react';

export class Sidebar extends Component{

    render() { 
        return ( 
            <div className="sidebar">
                <h2>sidebar</h2>
            </div>
         );
    }
}
 
