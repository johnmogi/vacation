import * as React from "react";
import { Component } from "react";
interface getCurrentYear {
  currentYear: number;
}
export class Footer extends Component<any, getCurrentYear> {
  public constructor(props: any) {
    super(props);
    this.state = {
      currentYear: new Date().getFullYear()
    };
  }
  render() {
    return (
      <div className="footer container-fluid">
        <p className="text-center">
          All rights reserved &copy;
          <a href="https://www.johnmogi.com">JohnMogi</a>
          {this.state.currentYear}
        </p>
      </div>
    );
  }
}
