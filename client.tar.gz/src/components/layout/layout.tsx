import * as React from "react";
import { Component } from "react";

import "./custom.css";
import { Header } from "./header";
import { Main } from "./main";
import { Sidebar } from "./sidebar";
import { Footer } from "./footer";
import Container from "react-bootstrap/Container";
import Jumbotron from "react-bootstrap/Jumbotron";
import { BrowserRouter } from "react-router-dom";

export class Layout extends Component {
  render() {
    return (
      <BrowserRouter>
        <div className="layout container-fluid">
          <Header />
          <section className="row">
            <aside className="col-2">
              <Sidebar />
            </aside>
            <main className="col-10">
              <Jumbotron fluid>
                <Container>
                  <Main />
                </Container>
              </Jumbotron>
            </main>

            <Footer />
          </section>
        </div>
      </BrowserRouter>
    );
  }
}
