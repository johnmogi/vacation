import * as React from "react";
import { Component } from "react";
import { NavbarComponent } from "./navbar/navbar";

export class Header extends Component {
  render() {
    return (
      <div className="header">
        <NavbarComponent />
      </div>
    );
  }
}
