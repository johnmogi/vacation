dbdesigner.net

הנחיות מורחבות לפרוייקט:

אין צורך להשתמש ב socket.io זה בונוס.

3 טבלאות כאשר השלישית היא רבים לרבים מספר עוקבים מתעדכן פר יוזר

דף לוגאין- בדיקת שם משתמש אם קיים focusup שליחת AJAX לשרת

3- סעיף 2 הוא בונוס (SOCKET.IO)

npm i express express-fileupload uuid

npm i express express-session

JSON WEB TOKEN - JWT

// project LOGIN - Session: isloggedin: true isadmin: true
