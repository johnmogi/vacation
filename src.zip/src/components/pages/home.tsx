import * as React from "react";
import { Component } from "react";

export class Home extends Component {
  render() {
    return (
      <div className="home">
        <h1>Sign in or register to follow vacations:</h1>

        <input type="text" />
      </div>
    );
  }
}
