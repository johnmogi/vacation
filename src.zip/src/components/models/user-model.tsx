export class UserModel {
  public constructor(public isAdmin?: boolean) {}
}
